"""
O'Neill Terrain Generator - Stroke-Based Y-Axis Wrapping System
Natural stroke wrapping without race conditions or artificial tiling zones
Replaces problematic real-time canvas monitoring approach
Minimal dependencies - only uses core Blender functionality
"""

import bpy
import time

class StrokeBasedYWrapping:
    """Natural stroke-based Y-axis wrapping without race conditions"""
    
    def __init__(self):
        self.canvas = None
        self.canvas_width = 0
        self.canvas_height = 0
        self.last_pixel_check = {}
        self.stroke_detection_active = False
        self.timer = None
        self.wrap_history = []  # Track wrapped regions to avoid double-wrapping
        
    def setup_y_wrapping_for_canvas(self, canvas):
        """Set up stroke-based Y-wrapping for a canvas"""
        if not canvas:
            print("❌ No canvas provided for Y-wrapping setup")
            return False
            
        self.canvas = canvas
        self.canvas_width = canvas.size[0]
        self.canvas_height = canvas.size[1]
        
        # Store initial pixel state for change detection
        self.last_pixel_check = self._get_canvas_checksum()
        
        print(f"✅ Y-wrapping setup for canvas: {self.canvas_width}x{self.canvas_height}")
        return True
    
    def start_stroke_monitoring(self):
        """Start monitoring for paint strokes to wrap"""
        if self.stroke_detection_active:
            return True
            
        if not self.canvas:
            print("❌ No canvas available for stroke monitoring")
            return False
        
        # Use a much lighter monitoring approach - just detect changes
        self.timer = bpy.app.timers.register(
            self._check_for_stroke_changes,
            first_interval=0.2,  # Check every 0.2 seconds
            persistent=True
        )
        
        self.stroke_detection_active = True
        print("✅ Stroke-based Y-wrapping monitoring started")
        return True
    
    def stop_stroke_monitoring(self):
        """Stop stroke monitoring"""
        if self.timer:
            try:
                bpy.app.timers.unregister(self.timer)
            except:
                pass
            self.timer = None
        
        self.stroke_detection_active = False
        print("⏹️ Stroke monitoring stopped")
    
    def _get_canvas_checksum(self):
        """Get a lightweight checksum of canvas state"""
        if not self.canvas:
            return {}
            
        try:
            pixels = self.canvas.pixels[:]
            # Sample every 10th pixel for performance
            sample_step = 10
            checksum = {}
            
            for i in range(0, len(pixels), sample_step * 4):
                if i + 3 < len(pixels):
                    pixel_pos = i // 4
                    r, g, b, a = pixels[i:i+4]
                    if r > 0.01 or g > 0.01 or b > 0.01:  # Non-black pixel
                        checksum[pixel_pos] = (r, g, b, a)
            
            return checksum
            
        except Exception as e:
            print(f"⚠️ Checksum calculation error: {e}")
            return {}
    
    def _check_for_stroke_changes(self):
        """Lightweight check for canvas changes and apply Y-wrapping"""
        try:
            if not self.canvas:
                return None  # Stop monitoring
            
            # Get current canvas state
            current_checksum = self._get_canvas_checksum()
            
            # Find new painted pixels
            new_pixels = {}
            for pos, pixel in current_checksum.items():
                if pos not in self.last_pixel_check:
                    new_pixels[pos] = pixel
            
            # If we found new paint strokes, check for Y-wrapping
            if new_pixels:
                self._apply_natural_y_wrapping(new_pixels)
                self.last_pixel_check = current_checksum
            
            # Continue monitoring
            return 0.2
            
        except Exception as e:
            print(f"❌ Stroke monitoring error: {e}")
            return None  # Stop on error
    
    def _apply_natural_y_wrapping(self, new_pixels):
        """Apply natural Y-axis wrapping for new paint strokes"""
        if not new_pixels:
            return
            
        try:
            # Get canvas dimensions
            width = self.canvas_width
            height = self.canvas_height
            
            # Calculate Y-wrapping parameters
            # Use same 5% overlap as UV mapping
            overlap_ratio = 0.05
            main_height = int(height / (1.0 + overlap_ratio))  # ~597 pixels
            wrap_zone_height = height - main_height  # ~31 pixels
            
            pixels = list(self.canvas.pixels[:])
            wrapped_pixels = []
            
            for pixel_pos, (r, g, b, a) in new_pixels.items():
                x = pixel_pos % width
                y = pixel_pos // width
                
                # Check if this pixel needs Y-wrapping
                wrap_target = None
                
                # Case 1: Bottom edge content wraps to top
                if y >= main_height:
                    # Pixel is in bottom wrap zone, copy to top
                    offset_from_bottom = y - main_height
                    target_y = offset_from_bottom
                    wrap_target = (x, target_y)
                
                # Case 2: Top edge content wraps to bottom
                elif y < wrap_zone_height:
                    # Pixel is in top wrap zone, copy to bottom
                    target_y = main_height + y
                    wrap_target = (x, target_y)
                
                # Apply wrapping if target found
                if wrap_target:
                    target_x, target_y = wrap_target
                    
                    # Bounds check
                    if 0 <= target_x < width and 0 <= target_y < height:
                        target_index = (target_y * width + target_x) * 4
                        
                        if target_index + 3 < len(pixels):
                            # Only wrap if target area is not already painted
                            target_pixel = pixels[target_index:target_index+4]
                            if target_pixel[0] < 0.01 and target_pixel[1] < 0.01 and target_pixel[2] < 0.01:
                                pixels[target_index:target_index+4] = [r, g, b, a]
                                wrapped_pixels.append((target_x, target_y))
            
            # Apply wrapped pixels to canvas if any were created
            if wrapped_pixels:
                self.canvas.pixels = pixels
                self.canvas.update()
                print(f"✅ Applied Y-wrapping to {len(wrapped_pixels)} pixels")
                
        except Exception as e:
            print(f"❌ Y-wrapping application error: {e}")
    
    def apply_manual_y_wrap(self):
        """Manually apply Y-wrapping to current canvas content"""
        if not self.canvas:
            print("❌ No canvas available for manual Y-wrapping")
            return False
            
        try:
            width = self.canvas_width
            height = self.canvas_height
            pixels = list(self.canvas.pixels[:])
            
            # Calculate wrap zone
            overlap_ratio = 0.05
            main_height = int(height / (1.0 + overlap_ratio))
            wrap_zone_height = height - main_height
            
            wrapped_count = 0
            
            # Copy bottom content to top
            for y in range(wrap_zone_height):
                source_y = main_height + y  # Bottom zone
                target_y = y  # Top zone
                
                for x in range(width):
                    source_index = (source_y * width + x) * 4
                    target_index = (target_y * width + x) * 4
                    
                    if (source_index + 3 < len(pixels) and target_index + 3 < len(pixels)):
                        source_pixel = pixels[source_index:source_index+4]
                        
                        # Only copy if source has painted content
                        if source_pixel[0] > 0.01 or source_pixel[1] > 0.01 or source_pixel[2] > 0.01:
                            # And target is empty
                            target_pixel = pixels[target_index:target_index+4]
                            if target_pixel[0] < 0.01 and target_pixel[1] < 0.01 and target_pixel[2] < 0.01:
                                pixels[target_index:target_index+4] = source_pixel
                                wrapped_count += 1
            
            # Copy top content to bottom
            for y in range(wrap_zone_height):
                source_y = y  # Top zone
                target_y = main_height + y  # Bottom zone
                
                for x in range(width):
                    source_index = (source_y * width + x) * 4
                    target_index = (target_y * width + x) * 4
                    
                    if (source_index + 3 < len(pixels) and target_index + 3 < len(pixels)):
                        source_pixel = pixels[source_index:source_index+4]
                        
                        # Only copy if source has painted content
                        if source_pixel[0] > 0.01 or source_pixel[1] > 0.01 or source_pixel[2] > 0.01:
                            # And target is empty
                            target_pixel = pixels[target_index:target_index+4]
                            if target_pixel[0] < 0.01 and target_pixel[1] < 0.01 and target_pixel[2] < 0.01:
                                pixels[target_index:target_index+4] = source_pixel
                                wrapped_count += 1
            
            if wrapped_count > 0:
                self.canvas.pixels = pixels
                self.canvas.update()
                print(f"✅ Manual Y-wrapping applied: {wrapped_count} pixels wrapped")
                return True
            else:
                print("ℹ️ No content to wrap")
                return False
                
        except Exception as e:
            print(f"❌ Manual Y-wrapping error: {e}")
            return False

# Global instance for integration
_stroke_wrapper = None

def get_stroke_wrapper():
    """Get global stroke wrapper instance"""
    global _stroke_wrapper
    if _stroke_wrapper is None:
        _stroke_wrapper = StrokeBasedYWrapping()
    return _stroke_wrapper

def setup_stroke_based_y_wrapping(canvas):
    """Setup stroke-based Y-wrapping for a canvas"""
    wrapper = get_stroke_wrapper()
    return wrapper.setup_y_wrapping_for_canvas(canvas)

def start_y_wrapping_monitoring():
    """Start Y-wrapping monitoring"""
    wrapper = get_stroke_wrapper()
    return wrapper.start_stroke_monitoring()

def stop_y_wrapping_monitoring():
    """Stop Y-wrapping monitoring"""
    wrapper = get_stroke_wrapper()
    wrapper.stop_stroke_monitoring()

def apply_manual_y_wrap():
    """Apply manual Y-wrapping to current canvas"""
    wrapper = get_stroke_wrapper()
    return wrapper.apply_manual_y_wrap()

# Blender operator for manual Y-wrapping
class ONEILL_OT_ApplyYWrapping(bpy.types.Operator):
    """Apply Y-axis wrapping to canvas manually"""
    bl_idname = "oneill.apply_y_wrapping"
    bl_label = "Apply Y-Axis Wrapping"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        canvas = bpy.data.images.get("oneill_terrain_canvas")
        if not canvas:
            self.report({'ERROR'}, "No canvas found")
            return {'CANCELLED'}
        
        wrapper = get_stroke_wrapper()
        if not wrapper.canvas:
            wrapper.setup_y_wrapping_for_canvas(canvas)
        
        success = wrapper.apply_manual_y_wrap()
        
        if success:
            self.report({'INFO'}, "Y-axis wrapping applied successfully")
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "No content to wrap")
            return {'CANCELLED'}

def register():
    """Register stroke-based Y-wrapping operators"""
    try:
        bpy.utils.register_class(ONEILL_OT_ApplyYWrapping)
        print("✅ Stroke-based Y-wrapping module registered")
    except Exception as e:
        print(f"❌ Registration error: {e}")

def unregister():
    """Unregister stroke-based Y-wrapping operators"""
    try:
        # Stop any active monitoring
        stop_y_wrapping_monitoring()
        
        bpy.utils.unregister_class(ONEILL_OT_ApplyYWrapping)
        print("⏹️ Stroke-based Y-wrapping module unregistered")
    except Exception as e:
        print(f"⚠️ Unregistration error: {e}")

if __name__ == "__main__":
    register()
