_painting_biome", text="🏔️")
            op.biome = 'MOUNTAINS'
            op = row1.operator("oneill.select_painting_biome", text="🏜️")
            op.biome = 'CANYONS'
            
            row2 = col.row(align=True)
            op = row2.operator("oneill.select_painting_biome", text="🏞️")
            op.biome = 'HILLS'
            op = row2.operator("oneill.select_painting_biome", text="🌵")
            op.biome = 'DESERT'
            op = row2.operator("oneill.select_painting_biome", text="🌊")
            op.biome = 'OCEAN'
            
            col.separator()
            
            # Preview system controls
            col.label(text="Apply Biome Previews:", icon='MODIFIER')
            preview_row = col.row(align=True)
            op = preview_row.operator("oneill.apply_biome_preview", text="Mountains")
            op.biome_type = 'MOUNTAINS'
            op = preview_row.operator("oneill.apply_biome_preview", text="Ocean") 
            op.biome_type = 'OCEAN'
            
            col.separator()
            
            # Control buttons
            col.operator("oneill.remove_all_previews")
            col.separator()
            col.operator("oneill.finish_terrain_painting")
            col.operator("oneill.exit_painting_mode")
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.oneill_props
        
        # CRITICAL FIX 5: Proper status indicator
        if props.painting_mode:
            box = layout.box()
            box.label(text="🎨 PAINTING MODE ACTIVE", icon='BRUSH_DATA')
            current_biome_display = get_biome_display_name(props.current_biome)
            box.label(text=f"Current: {current_biome_display}")
        
        # Step 1: Align Cylinders
        box = layout.box()
        box.label(text="1. Align Cylinders", icon='OBJECT_DATA')
        row = box.row()
        row.prop(props, "alignment_axis")
        box.operator("oneill.align_cylinders")
        
        # Step 2: Unwrap to Flat
        box = layout.box()
        box.label(text="2. Unwrap to Flat", icon='MOD_UVPROJECT')
        box.prop(props, "subdivision_levels")
        box.operator("oneill.unwrap_to_flat") 
               
        # Step 3: Create Heightmaps
        box = layout.box()
        box.label(text="3. Create Heightmaps", icon='IMAGE_DATA')
        box.prop(props, "heightmap_resolution")
        box.operator("oneill.create_heightmaps")
        
        # Step 4: Paint Terrain Biomes (Enhanced with Phase 2A)
        box = layout.box()
        box.label(text="4. Paint Terrain Biomes", icon='BRUSH_DATA')
        
        # Use the enhanced painting controls
        self.draw_enhanced_painting_controls(context, box)
        
        # Step 5: Rewrap to Cylinders
        box = layout.box()
        box.label(text="5. Rewrap to Cylinders", icon='MESH_CYLINDER')
        box.operator("oneill.rewrap_to_cylinders")

class Phase2ARealtimeMonitor:
    """Phase 2A Real-time paint monitoring system"""
    
    def __init__(self):
        self.active = False
        self.update_interval = 0.5  # 2 FPS for responsive performance
        self.last_canvas_hash = None
        self.change_count = 0
        self.total_updates = 0
        
    def get_canvas_hash(self):
        """Efficient change detection via sampling"""
        canvas = bpy.data.images.get("ONeill_Terrain_Canvas")
        if not canvas:
            return None
            
        pixels = list(canvas.pixels)
        sample_size = min(len(pixels), 40000)  # 10k pixels * 4 channels
        sample_step = max(1, len(pixels) // sample_size)
        
        sample_data = bytes(int(pixels[i] * 255) for i in range(0, len(pixels), sample_step))
        return hashlib.md5(sample_data).hexdigest()
    
    def realtime_callback(self):
        """Core Phase 2A timer callback"""
        try:
            if not self.active:
                return None  # Stop timer when inactive
                
            current_hash = self.get_canvas_hash()
            self.total_updates += 1
            
            if current_hash and current_hash != self.last_canvas_hash:
                self.change_count += 1
                print(f"🎨 Real-time change #{self.change_count} detected")
                
                # Apply biomes using paint detection
                result = bpy.ops.oneill.detect_paint_apply_previews()
                if result == {'FINISHED'}:
                    print(f"✅ Real-time terrain update applied")
                
                self.last_canvas_hash = current_hash
            
            return self.update_interval  # Continue monitoring
            
        except Exception as e:
            print(f"❌ Real-time error: {e}")
            return self.update_interval

# Create global monitor instance
PHASE2A_MONITOR = Phase2ARealtimeMonitor()

# ========================= FIXED REGISTRATION =========================

classes = [
    OneillProperties,
    ONEILL_OT_AlignCylinders,
    ONEILL_OT_UnwrapToFlat,
    ONEILL_OT_CreateHeightmaps,
    ONEILL_OT_GenerateTerrain,
    ONEILL_OT_RewrapToCylinders,
    ONEILL_OT_StartTerrainPainting,
    ONEILL_OT_SelectPaintingBiome,   # CRITICAL FIX 9: Added missing operator
    ONEILL_OT_ApplyBiomePreview,
    ONEILL_OT_RemoveAllPreviews,
    ONEILL_OT_FinishTerrainPainting,
    ONEILL_OT_ExitPaintingMode,
    ONEILL_PT_MainPanel,
    ONEILL_OT_DetectPaintApplyPreviews,
    ONEILL_OT_StartRealtimeMonitoring,
    ONEILL_OT_StopRealtimeMonitoring,
]

def register():
    """Register all classes and properties"""
    for cls in classes:
        bpy.utils.register_class(cls)
        
    bpy.types.Scene.oneill_props = bpy.props.PointerProperty(type=OneillProperties)
    
    # Initialize grid overlay
    global grid_overlay
    grid_overlay = TerrainPaintingGridOverlay()
    
    print("O'Neill Terrain Generator v2.3.1 - CRITICAL FIXES APPLIED - registered successfully")

def unregister():
    """Unregister all classes and properties"""
    # Disable grid overlay
    global grid_overlay
    if grid_overlay:
        grid_overlay.disable()
        
    # Unregister classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
        
    # Remove scene property
    if hasattr(bpy.types.Scene, 'oneill_props'):
        del bpy.types.Scene.oneill_props
        
    print("O'Neill Terrain Generator v2.3.1 unregistered")

if __name__ == "__main__":
    register()
